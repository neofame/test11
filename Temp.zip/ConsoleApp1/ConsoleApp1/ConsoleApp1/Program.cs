﻿// See https://aka.ms/new-console-template for more information
using com.javainuse.employee;
using Grpc.Net.Client;

Console.WriteLine("Hello, World!");

var channel = GrpcChannel.ForAddress("http://localhost:8090");
var client = new BookService.BookServiceClient(channel);
BookRequest bookRequest = new BookRequest();
bookRequest.BookId = "1";
var reply = await client.getBookAsync(bookRequest);

Console.WriteLine(reply.ToString());


