﻿using Grpc.Core;
using Helloworld;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;
using Microsoft.Extensions.Hosting;
using Microsoft.Extensions.DependencyInjection;
using System.Threading;
using System.Net.Http.Headers;
using Login;
using Google.Protobuf.WellKnownTypes;


namespace GrpcServerConsole
{
    class GreeterImpl : Greeter.GreeterBase
    {
        // Server side handler of the SayHello RPC
        public override Task<HelloReply> SayHello(HelloRequest request, ServerCallContext context)
        {
            //string text = File.ReadAllText(@"D:\tmp\Erpmate\complte\complte\kk.txt");


            return Task.FromResult(new HelloReply { Message = @" D:\Tools\Sql\OracleConnectionTest" + request.Name });
        }

 
    }

    class LoginImp : LoginService.LoginServiceBase
    {
        public override Task<ResponseMessage> LoginBankService(EmployeeModel request, ServerCallContext context)
        {
            //string text = File.ReadAllText(@"D:\개발 Project Source\Inhouse\script.sql");


            return Task.FromResult(new ResponseMessage { Message =  request.Date + request.Email + request.Name + request.Skill,
            Status = 1, Success = true });
        }

        public override Task<ResponseMessage> GetAllEmployee(Empty empty, ServerCallContext context)
        {
           // string text = File.ReadAllText(@"D:\개발 Project Source\Inhouse\script.sql");

            return Task.FromResult(new ResponseMessage
            {
                Message = "request.Date",
                Status = 1,
                Success = true
            });
        }

    }


    public class GrpcHostedService : IHostedService
    {
        private Server _server;

        public GrpcHostedService(Server server)
        {
            _server = server;

        }

        public Task StartAsync(CancellationToken cancellationToken)
        {
            _server.Start();
            return Task.CompletedTask;
        }

        public async Task StopAsync(CancellationToken cancellationToken) => await _server.ShutdownAsync();

    }


    class Program
    {
        const int Port = 30052;

        public static async Task Main(string[] args)
        {
            var hostBuilder = new HostBuilder()
                // Add configuration, logging, ...
                .ConfigureServices((hostContext, services) =>
                {
                    var channelOptions = new List<ChannelOption>();
                    channelOptions.Add(new ChannelOption(ChannelOptions.MaxReceiveMessageLength, 160000));

        // Better to use Dependency Injection for GreeterImpl
                     Server server = new Server(channelOptions)
                    {
                        Services = {
                            Greeter.BindService(new GreeterImpl()), 
                            LoginService.BindService(new LoginImp())
                        },
                        Ports = { new ServerPort("localhost", Port, ServerCredentials.Insecure) }
                    };
                    services.AddSingleton<Server>(server);
                    services.AddSingleton<IHostedService, GrpcHostedService>();

                });

            await hostBuilder.StartAsync();
            Console.ReadLine();

        }


    }
}
