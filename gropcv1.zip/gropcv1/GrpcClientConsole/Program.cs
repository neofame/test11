﻿using Google.Protobuf.WellKnownTypes;
using Grpc.Core;
using Helloworld;
using Login;
using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GrpcClientConsole
{
    internal class Program
    {
/*        public static readonly NLog.Logger Logger = NLog.LogManager.GetCurrentClassLogger();

        static void Log()
        {
            NLog.LogManager.Configuration = new NLog.Config.XmlLoggingConfiguration(@".\AppLog.config");

            Console.WriteLine("Start");

            try
            {
                Logger.Trace("My Trace");
                Logger.Debug("My Debug");
                Logger.Info("My Info");
                Logger.Warn("My Warn");
                Logger.Error("My Error");

                // throw new Exception("My Exception", new Exception("My Inner Exception"));
            }
            catch (Exception ex) { }

        }*/

        static void Main(string[] args)
        {
            //Program.Log();

            var channelOptions = new List<ChannelOption>();
            channelOptions.Add(new ChannelOption(ChannelOptions.MaxReceiveMessageLength, 1000000000));
            channelOptions.Add(new ChannelOption(ChannelOptions.MaxSendMessageLength, 1000000000));

            Channel channel = new Channel("127.0.0.1:30052", ChannelCredentials.Insecure, channelOptions);

            var client = new Greeter.GreeterClient(channel);

            //Console.WriteLine(" Press any key to Start...");
            //Console.Read();
            // string text = File.ReadAllText(@"D:\Application\Development\Database\MS Sql Server\instnwnd.sql");
            var reply = client.SayHello(new HelloRequest { Name = "Admin" });
            // Console.WriteLine("Greeting: " + reply.Message);

            var client1 = new LoginService.LoginServiceClient(channel);

            DateTime current = DateTime.ParseExact("18/08/2015 06:30:15.006542", "dd/MM/yyyy HH:mm:ss.ffffff", CultureInfo.InvariantCulture);

            var reply1 = client1.LoginBankService(new EmployeeModel { Date = "222", Email = "#fsdfsdf", Name = "USERNAME", Skill = "mANIC" });

            var reply2 = client1.GetAllEmployee(new Empty());

            Console.WriteLine("Greeting: " + reply.Message);

            Console.WriteLine("LoginService: {0} , {1}, {2}", reply1.Message, reply1.Status, reply1.Success);

            Console.WriteLine("GetAllEmployee: {0}  , {1}, {2}", reply2.Success, reply2.Message, reply2.Status);

            channel.ShutdownAsync().Wait();
            Console.WriteLine("Press any key to exit...");
            Console.ReadKey();
        }
    }
}
