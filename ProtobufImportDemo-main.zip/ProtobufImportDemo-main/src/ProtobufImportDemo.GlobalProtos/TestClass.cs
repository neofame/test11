﻿using Acme.Demo.V1;

namespace ProtobufImportDemo.LocalProtos;

public class TestClass
{
    public Foo TestProp { get; set; } = default!;
}
