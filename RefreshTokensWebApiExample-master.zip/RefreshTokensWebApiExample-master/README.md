# Refresh Tokens in ASP.NET Web Api Core Demo Project

Example of a Web Api built using ASP.NET Core that uses refresh tokens to keep the user signed in.

To find out more about using Refresh and JSON Web Tokens in ASP.NET Core read the [blog post](https://www.blinkingcaret.com/2018/05/30/refresh-tokens-in-asp-net-core-web-api/) for which this repo is the sample project.