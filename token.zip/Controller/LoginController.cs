﻿using Microsoft.IdentityModel.Tokens;
using System;
using System.Collections.Generic;
using System.IdentityModel.Tokens.Jwt;
using System.Linq;
using System.Security.Claims;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;
using System.Web.Http;

namespace token.Controller
{
    class LoginController : ApiController
    {
        [HttpGet]
        public IHttpActionResult Get(string loginId)
        {
            /*            loginrequest.Username = login.Username.ToLower();
                        loginrequest.Password = login.Password;

                        IHttpActionResult response;
                        //HttpResponseMessage responseMsg = new HttpResponseMessage();
                        bool isUsernamePasswordValid = false;

                        if (login != null)
                            isUsernamePasswordValid = loginrequest.Password == "admin" ? true : false;
                        // if credentials are valid
                        if (isUsernamePasswordValid)
                        {
                            string token = createToken(loginrequest.Username);
                            //return the token
                            return Ok<string>(token);
                        }
                        else
                        {
                            // if credentials are not valid send unauthorized status code in response
                            loginResponse.responseMsg.StatusCode = HttpStatusCode.Unauthorized;
                            response = ResponseMessage(loginResponse.responseMsg);
                            return response;
                        }*/

     /*       HttpContext.GetTokenAsync("access_token"); 
            HttpContext.GetTokenAsync("refresh_token"); */


            string token = createToken("loginrequest.Username");
            
            //return the token
            return Ok<string>(token);
        }

        //public async Task<AuthenticationResult> AuthenticateAsync(UsersMaster user)
        //{
        //    // authentication successful so generate jwt token
        //    AuthenticationResult authenticationResult = new AuthenticationResult();
        //    var tokenHandler = new JwtSecurityTokenHandler();

        //    try
        //    {
        //        var key = Encoding.ASCII.GetBytes(_appSettings.JwtSettings.Secret);

        //        ClaimsIdentity Subject = new ClaimsIdentity(new Claim[]
        //        {
        //            new Claim("UserId", user.UserId.ToString()),
        //            new Claim("FirstName", user.FirstName),
        //            new Claim("LastName",user.LastName),
        //            new Claim("EmailId",user.Email==null?"":user.Email),
        //            new Claim("UserName",user.UserName==null?"":user.UserName),
        //            new Claim(JwtRegisteredClaimNames.Jti, Guid.NewGuid().ToString()),
        //        });
        //        foreach (var item in GetUserRole(user.UserId))
        //        {
        //            Subject.AddClaim(new Claim(ClaimTypes.Role, item.RoleName));
        //        }

        //        var tokenDescriptor = new SecurityTokenDescriptor
        //        {
        //            Subject = Subject,
        //            Expires = DateTime.UtcNow.Add(_appSettings.JwtSettings.TokenLifetime),
        //            SigningCredentials = new SigningCredentials(new SymmetricSecurityKey(key), SecurityAlgorithms.HmacSha256Signature)
        //        };
        //        var token = tokenHandler.CreateToken(tokenDescriptor);
        //        authenticationResult.Token = tokenHandler.WriteToken(token);
        //        var refreshToken = new RefreshToken
        //        {
        //            Token = Guid.NewGuid().ToString(),
        //            JwtId = token.Id,
        //            UserId = user.UserId,
        //            CreationDate = DateTime.UtcNow,
        //            ExpiryDate = DateTime.UtcNow.AddMonths(6)
        //        };
        //        await _context.RefreshToken.AddAsync(refreshToken);
        //        await _context.SaveChangesAsync();
        //        authenticationResult.RefreshToken = refreshToken.Token;
        //        authenticationResult.Success = true;
        //        return authenticationResult;
        //    }
        //    catch (Exception ex)
        //    {
        //        return null;
        //    }

        //}

        private string createToken(string username)
        {
            //Set issued at date
            DateTime issuedAt = DateTime.UtcNow;
            //set the time when it expires
            DateTime expires = DateTime.UtcNow.AddMinutes(15);

            //http://stackoverflow.com/questions/18223868/how-to-encrypt-jwt-security-token
            var tokenHandler = new JwtSecurityTokenHandler();

            //create a identity and add claims to the user which we want to log in
            ClaimsIdentity claimsIdentity = new ClaimsIdentity(new[]
            {
                new Claim(ClaimTypes.Name, username)
            });

            const string secret = "401b09eab3c013d4ca54922bb802bec8fd5318192b0a75f201d8b3727429090fb337591abd3e44453b954555b7a0812e1081c39b740293f765eae731f5a65ed1";
            var now = DateTime.UtcNow;
            var securityKey = new Microsoft.IdentityModel.Tokens.SymmetricSecurityKey(System.Text.Encoding.Default.GetBytes(secret));
            var signingCredentials = new Microsoft.IdentityModel.Tokens.SigningCredentials(securityKey, Microsoft.IdentityModel.Tokens.SecurityAlgorithms.HmacSha256Signature);


            //create the jwt
            var token =
                (JwtSecurityToken)
                    tokenHandler.CreateJwtSecurityToken(issuer: "http://localhost:9090", audience: "http://localhost:9090",
                        subject: claimsIdentity, notBefore: issuedAt, expires: expires, signingCredentials: signingCredentials);
            var tokenString = tokenHandler.WriteToken(token);

            return tokenString;
        }

        public string GenerateRefreshToken()
        {
            var randomNumber = new byte[32];
            using (var rng = RandomNumberGenerator.Create())
            {
                rng.GetBytes(randomNumber);
                return Convert.ToBase64String(randomNumber);
            }
        }
        public  string GenerateAccessTokenFromRefreshToken(string refreshToken, string secret)
        {
            // Implement logic to generate a new access token from the refresh token
            // Verify the refresh token and extract necessary information (e.g., user ID)
            // Then generate a new access token

            // For demonstration purposes, return a new token with an extended expiry
            var tokenHandler = new JwtSecurityTokenHandler();
            var key = Encoding.Default.GetBytes(secret);

            var tokenDescriptor = new SecurityTokenDescriptor
            {
                Expires = DateTime.Now.AddMinutes(15), // Extend expiration time
                SigningCredentials = new SigningCredentials(new SymmetricSecurityKey(key), SecurityAlgorithms.HmacSha256Signature)
            };

            var token = tokenHandler.CreateToken(tokenDescriptor);
            return tokenHandler.WriteToken(token);
        }
    }
}
