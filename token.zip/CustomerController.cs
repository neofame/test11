﻿using Microsoft.Extensions.Primitives;
using Microsoft.Graph;
using Microsoft.IdentityModel.Tokens;
using System;
using System.Collections.Generic;
using System.IdentityModel.Tokens.Jwt;
using System.Net.Http;
using System.Security.Claims;
using System.Security.Cryptography;
using System.Text;
using System.Web;
using System.Web.Http;

namespace token
{
    public class CustomerController : ApiController
    {
        const string sec = "401b09eab3c013d4ca54922bb802bec8fd5318192b0a75f201d8b3727429090fb337591abd3e44453b954555b7a0812e1081c39b740293f765eae731f5a65ed1";
        // Gets
        [HttpGet]
        public Customer Get(string customerId)
        {


            //var labels = TraceLabels.FromHttpRequestMessage(request);
            //Assert.Single(labels);
            //Assert.Equal("PUT", labels[TraceLabels.HttpMethod]);

            //var context = Request.Properties["MS_HttpContext"] as HttpContextWrapper;
            //var sessionId = context.Request.Params["ASP.NET_SessionId"];
            //var context1 = Request.Properties["MS_HttpContext"] as HttpContext;
            //context1.GetOwinContext().Request.Headers.TryGetValue
            //var cookies = HttpContext.Current.Request.Cookies;

            //string kotken = createToken("username","id");
            //string refredh = GenerateRefreshToken();
            //string refredhdo = GenerateAccessTokenFromRefreshToken(refredh, sec);


            string currentLocation = "";

 /*           if (context1.Request.Headers.GetValues().TryGetValue("data-location", out StringValues locationHeaders) && locationHeaders.Any())
            {
                currentLocation = locationHeaders.First();
            }*/


            return new Customer()
            {
                ID = Int32.Parse(customerId),
                LastName = "Smith",
                FirstName = "Mary",
                HouseNumber = "333",
                Street = sec,
                City = "Redmond",
                State = "WA",
                ZipCode = "98053"
            };
        }

    //  [HttpPost("refresh")]
    //public IActionResult Refresh(TokenResponse tokenResponse)
    //{
    //    // For simplicity, assume the refresh token is valid and stored securely
    //    // var storedRefreshToken = _userService.GetRefreshToken(userId);

    //    // Verify refresh token (validate against the stored token)
    //    // if (storedRefreshToken != tokenResponse.RefreshToken)
    //    //    return Unauthorized();

    //    // For demonstration, let's just generate a new access token
    //    var newAccessToken = TokenUtils.GenerateAccessTokenFromRefreshToken(tokenResponse.RefreshToken, _config["Jwt:Secret"]);

    //    var response = new TokenResponse
    //    {
    //        AccessToken = newAccessToken,
    //        RefreshToken = tokenResponse.RefreshToken // Return the same refresh token
    //    };

    //    return Ok(response);
    //}
        private string createToken(string username, string id)
        {
            //Set issued at date
            DateTime issuedAt = DateTime.Now;
            //set the time when it expires
            DateTime expires = DateTime.Now.AddMinutes(10);

            //http://stackoverflow.com/questions/18223868/how-to-encrypt-jwt-security-token
            var tokenHandler = new JwtSecurityTokenHandler();

            //create a identity and add claims to the user which we want to log in
            ClaimsIdentity claimsIdentity = new ClaimsIdentity(new[]
            {
                new Claim(ClaimTypes.NameIdentifier, id),
                new Claim(ClaimTypes.Name, username)
            });

     
            var now = DateTime.Now;
            var securityKey = new Microsoft.IdentityModel.Tokens.SymmetricSecurityKey(System.Text.Encoding.Default.GetBytes(sec));
            var signingCredentials = new Microsoft.IdentityModel.Tokens.SigningCredentials(securityKey, Microsoft.IdentityModel.Tokens.SecurityAlgorithms.HmacSha256Signature);


            //create the jwt
            var token =
                (JwtSecurityToken)
                    tokenHandler.CreateJwtSecurityToken(issuer: "http://localhost:9090", audience: "http://localhost:9090",
                        subject: claimsIdentity, notBefore: issuedAt, expires: expires, signingCredentials: signingCredentials);
            var tokenString = tokenHandler.WriteToken(token);

            return tokenString;
        }
        public string GenerateJWTToken(string user, string id)
        {
            var claims = new List<Claim> {
        new Claim(ClaimTypes.NameIdentifier, id),
        new Claim(ClaimTypes.Name, user),
    };
            var jwtToken = new JwtSecurityToken(
                claims: claims,
                notBefore: DateTime.Now,
                expires: DateTime.Now.AddDays(30),
                signingCredentials: new SigningCredentials(
                    new Microsoft.IdentityModel.Tokens.SymmetricSecurityKey(Encoding.UTF8.GetBytes("ApplicationSettings:JWT_Secret")),
                     SecurityAlgorithms.HmacSha256Signature,
                    System.IdentityModel.Tokens.SecurityAlgorithms.Sha256Digest
                   )
                );
            return new JwtSecurityTokenHandler().WriteToken(jwtToken);
        }


        public string GenerateRefreshToken()
        {
            var randomNumber = new byte[32];
            using (var rng = RandomNumberGenerator.Create())
            {
                rng.GetBytes(randomNumber);
                return Convert.ToBase64String(randomNumber);
            }
        }
        public string GenerateAccessTokenFromRefreshToken(string refreshToken, string secret)
        {
            // Implement logic to generate a new access token from the refresh token
            // Verify the refresh token and extract necessary information (e.g., user ID)
            // Then generate a new access token

            // For demonstration purposes, return a new token with an extended expiry
            var tokenHandler = new JwtSecurityTokenHandler();
            var key = Encoding.Default.GetBytes(secret);

            var tokenDescriptor = new SecurityTokenDescriptor
            {
                Expires = DateTime.Now.AddMinutes(15), // Extend expiration time
                SigningCredentials = new SigningCredentials(new SymmetricSecurityKey(key), SecurityAlgorithms.HmacSha256Signature)
            };

            var token = tokenHandler.CreateToken(tokenDescriptor);
            return tokenHandler.WriteToken(token);
        }

        //public RefreshTokenGenerator(Learn_DBContext learn_DB)
        //{
        //    context = learn_DB;
        //}
        //public string GenerateToken(string username)
        //{
        //    var randomnumber = new byte[32];
        //    using (var randomnumbergenerator = RandomNumberGenerator.Create())
        //    {
        //        randomnumbergenerator.GetBytes(randomnumber);
        //        string RefreshToken = Convert.ToBase64String(randomnumber);

        //        var _user = context.TblRefreshtoken.FirstOrDefault(o => o.UserId == username);
        //        if (_user != null)
        //        {
        //            _user.RefreshToken = RefreshToken;
        //            context.SaveChanges();
        //        }
        //        else
        //        {
        //            TblRefreshtoken tblRefreshtoken = new TblRefreshtoken()
        //            {
        //                UserId = username,
        //                TokenId = new Random().Next().ToString(),
        //                RefreshToken = RefreshToken,
        //                IsActive = true
        //            };
        //        }

        //        return RefreshToken;
        //    }
        //}
    }
}
