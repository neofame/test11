﻿using Microsoft.Owin.Hosting;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Security;
using System.Security.Cryptography.X509Certificates;
using System.Text;
using System.Threading.Tasks;
using System.Web.Mvc;

namespace token
{
    internal class Program
    {
        static void Main(string[] args)
        {

            InstallCertificate(StoreLocation.LocalMachine, StoreName.Root, @"D:\tmp\Erpmate\toe.pfx");
            InstallCertificate(StoreLocation.LocalMachine, StoreName.TrustedPublisher, @"D:\tmp\Erpmate\toe.pfx");

            string baseAddress = "http://localhost:9090/";

            // Start OWIN host
            IDisposable signalR = null;
            signalR = WebApp.Start<Startup>(url: baseAddress);
            // using ()
            {
                // Create HttpCient and make a request to api/values
                HttpClient client = new HttpClient();

               // HttpResponseMessage response = client.GetAsync(baseAddress + "api/values").Result;
                HttpResponseMessage response = client.GetAsync(baseAddress + "Customer/1").Result;
                

                Console.WriteLine(response);
                Console.WriteLine(response.Content.ReadAsStringAsync().Result);
            }


            string uri = "http://localhost:9999/";
            using (WebApp.Start<StartupSignalR>(uri))
            {
                Console.WriteLine("Started");
                // Open the SignalR negotiation page to make sure things are working.
                Process.Start(uri + "signalr/negotiate");
                Console.ReadKey();
                Console.WriteLine("Finished");
            }

            Console.ReadLine();
        }
        private static string DownloadCertifcate(string certUrl)
        {
            string tempFilePath = Path.GetTempFileName();

            WebClient wc = new WebClient();
            wc.DownloadFile(certUrl, tempFilePath);

            return tempFilePath;
        }

        private static void InstallCertificate(StoreLocation storeLocation, StoreName storeName, string certFilePath)
        {
/*            X509Store store = new X509Store(storeName, storeLocation);
            store.Open(OpenFlags.ReadWrite);
            SecureString theSecureString = new NetworkCredential("", "1234").SecurePassword;
            store.Add(new X509Certificate2(X509Certificate2.CreateFromCertFile(certFilePath), new NetworkCredential("", "1234").SecurePassword));
            store.Close();*/

            X509Certificate2 cert = new X509Certificate2(certFilePath, "1234");
            X509Store store = new X509Store(storeName, storeLocation);
            store.Open(OpenFlags.ReadWrite);
            store.Add(cert);
/*
            X509Certificate2 cert = new X509Certificate2("a.pfx", "password", X509KeyStorageFlags.MachineKeySet);
            X509Store store = new X509Store(StoreName.My, StoreLocation.LocalMachine);
            store.Open(OpenFlags.ReadWrite);
            store.Add(xCertificate);*/
        }
    }
}
