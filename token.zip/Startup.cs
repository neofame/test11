﻿using Owin;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Owin;
using Owin;
using Microsoft.Owin.Security;
using Microsoft.Owin.Security.Cookies;
using Microsoft.Identity.Web.OWIN;
using Microsoft.Identity.Web;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Identity.Client;
using Microsoft.Identity.Web.TokenCacheProviders.InMemory;
using System.IO;
using Microsoft.Owin.Builder;
using Microsoft.Owin.Security.OAuth;
using System.Web.Http;
using Microsoft.Owin.Security.Jwt;
using Microsoft.Extensions.Options;
using Microsoft.IdentityModel.Tokens;

namespace token
{
    class Startup
    {
/*        private void ConfigureOAuth(IAppBuilder app)
        {
            // For more information on how to configure your application, //visit 
            OAuthAuthorizationServerOptions option = new OAuthAuthorizationServerOptions
            {

                TokenEndpointPath = new PathString("/token"),
                Provider = new ApplicationAuthProvider(),
                AccessTokenExpireTimeSpan = TimeSpan.FromMinutes(60),
                AllowInsecureHttp = true
            };
            app.UseOAuthAuthorizationServer(option);
            app.UseOAuthBearerAuthentication(new OAuthBearerAuthenticationOptions());
            }
        }*/

        public void Configuration(IAppBuilder app)
        {

            /*            var config = new HttpConfiguration();
                        WebApiConfig.Register(config);
                        app.UseCors(Microsoft.Owin.Cors.CorsOptions.AllowAll);*/

           // WebApiConfig.Register(config);


            var config = new HttpConfiguration();


            // config.Routes.MapHttpRoute("default", "{controller}");
            config.Routes.MapHttpRoute("Default", "{controller}/{customerID}", new { controller = "Customer", customerID = RouteParameter.Optional });
            config.Routes.MapHttpRoute( "API Default", "{controller}/{id}",    new { id = RouteParameter.Optional });
            // config.Formatters.XmlFormatter.UseXmlSerializer = true;
            // config.Formatters.Remove(config.Formatters.JsonFormatter);
            config.Formatters.JsonFormatter.UseDataContractJsonSerializer = true;

            app.UseWebApi(config);

            return;
            var options = new JwtBearerAuthenticationOptions();

           // options.SaveToken = true;
          //  options.RequireHttpsMetadata = false;
            options.TokenValidationParameters = new TokenValidationParameters()
            {
                ValidateIssuer = true,
                ValidateAudience = true,
                ValidateLifetime = true,
                ValidateIssuerSigningKey = true,
                ClockSkew = TimeSpan.Zero,

                ValidAudience = "JWT:ValidAudience",
                ValidIssuer = "JWT:ValidIssuer",
                IssuerSigningKey = new SymmetricSecurityKey(Encoding.UTF8.GetBytes("JWT:Secret"))
            };
            app.UseJwtBearerAuthentication(options);
/*
            app.UseJwtBearerAuthentication(
  new JwtBearerAuthenticationOptions
  {
      AuthenticationMode = AuthenticationMode.Active,
      TokenValidationParameters = new TokenValidationParameters()
      {
          ValidAudience = ConfigHelper.GetAudience(),
          ValidIssuer = ConfigHelper.GetIssuer(),
          ValidateLifetime = true,
          ValidateIssuerSigningKey = true
      }
  });*/

            /*            app.UseJwtBearerAuthentication(new JwtBearerOptions
                        {
                            //AutomaticAuthenticate = true,
                            //AutomaticChallenge = true,
                            TokenValidationParameters = new TokenValidationParameters
                            {
                                // The signing key must match!
                                ValidateIssuerSigningKey = true,
                                IssuerSigningKey = new SymmetricSecurityKey(Encoding.UTF8.GetBytes(Configuration.GetSection("AppConfiguration:Key").Value)),

                                // Validate the JWT Issuer (iss) claim  
                                ValidateIssuer = true,
                                ValidIssuer = Configuration.GetSection("AppConfiguration:SiteUrl").Value,

                                // Validate the JWT Audience (aud) claim  
                                ValidateAudience = true,
                                ValidAudience = Configuration.GetSection("AppConfiguration:SiteUrl").Value,

                                // Validate the token expiry  
                                ValidateLifetime = true,

                                ClockSkew = TimeSpan.Zero
                            }
                        });*/

            foreach (var item in app.Properties)
            {
                //Console.WriteLine(item.Key + " - " + item.Value);
                if (item.Key == "host.Addresses")
                {
                    dynamic d = item.Value;
                    var items = (Dictionary<string, object>)d[0];
                    // Here there are four keys for scheme , host , port , path
                    foreach (var add in items)
                    {
                        Console.WriteLine(add.Key + " - " + add.Value);
                    }
                }
            }

            app.Use(async (ctx, next) =>
            {
                await ctx.Response.WriteAsync(DateTime.Now.ToString() + " My First OWIN App");
            });

            app.Run(async context =>
            {
                await context.Response.WriteAsync(getTime() + " My First OWIN App");
            });
            app.Run(context =>
            {
                string t = DateTime.Now.Millisecond.ToString();
                return context.Response.WriteAsync(t + " Production OWIN App");
            });
            app.Use((context, next) =>
            {
                TextWriter output = context.Get<TextWriter>("host.TraceOutput");
                return next().ContinueWith(result =>
                {
                    output.WriteLine("Scheme {0} : Method {1} : Path {2} : MS {3}",
                    context.Request.Scheme, context.Request.Method, context.Request.Path, getTime());
                });
            });
            app.Run(Invoke);

/*            app.Run(context =>
            {
                context.Response.ContentType = "application/json";
                return context.Response.WriteAsync("Hello World!");
            });*/
        }

        // Invoked once per request.
        public Task Invoke(IOwinContext context)
        {
            context.Response.ContentType = "application/json";
            return context.Response.WriteAsync("Hello World");
        }
        string getTime()
        {
            return DateTime.Now.Millisecond.ToString();
        }
    }
}
