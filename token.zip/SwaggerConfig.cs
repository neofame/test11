﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Web.Http;

namespace token
{
    public class SwaggerConfig
    {
        public static void Register(HttpConfiguration httpConfig)
        {
            var thisAssembly = typeof(SwaggerConfig).Assembly;
/*
            httpConfig
                 .EnableSwagger(c =>
                 {
                     // API version definition
                     c.SingleApiVersion("v1", "AspNetWebAPIOauth2");
                     // Token 
                     c.ApiKey("Token")
                        .Description("Bearer token")
                        .Name("Authorization")
                        .In("header");
                     c.DocumentFilter<AuthTokenDocumentFilter>();
                 })
                 .EnableSwaggerUi(c =>
                 {
                     // If your API supports ApiKey, you can override the default values.
                     // "apiKeyIn" can either be "query" or "header"                                                
                     //
                     c.EnableApiKeySupport("Authorization", "header");
                 });*/
        }
    }
}
