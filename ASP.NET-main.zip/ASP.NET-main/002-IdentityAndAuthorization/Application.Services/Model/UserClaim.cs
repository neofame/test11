﻿namespace Application.Services.Model
{
    public class UserClaim
    {
        public string Type { get; set; }
        public string Value { get; set; }
    }
}
