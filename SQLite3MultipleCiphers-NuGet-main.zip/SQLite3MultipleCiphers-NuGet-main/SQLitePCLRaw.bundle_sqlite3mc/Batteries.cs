﻿namespace SQLitePCL
{
    public static class Batteries
    {
        public static void Init()
            => Batteries_V2.Init();
    }
}
