﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ExampleGUI
{
    static class Constants
    {
        public const string PIPE_NAME = "named_pipe_test_server";
    }
}
