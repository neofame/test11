﻿namespace JWTRefreshTokenInDotNet6.Models
{
    public class AddRoleModel
    {
        public string UserId { get; set; }
        public string Role { get; set; }
    }
}