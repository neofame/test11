﻿/* Copyright Xeno Innovations, Inc. 2019
 * Date:    2019-9-13
 * Author:  Damian Suess
 * File:    sqlite_sequence.cs
 * Description:
 *
 */

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Test.SQLiteX.SystemTables
{
  class sqlite_sequence
  {
  }
}
