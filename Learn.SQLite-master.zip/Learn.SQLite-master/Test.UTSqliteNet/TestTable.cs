﻿/* Copyright Xeno Innovations, Inc. 2019
 * Date:    2019-9-13
 * Author:  Damian Suess
 * File:    TestTable.cs
 * Description:
 *
 */

namespace Test.SQLiteX
{
  public class TestTable
  {
    public string MyParameter { get; set; }

    public string ParamValue { get; set; }

    public int SomeInt { get; set; }
  }
}