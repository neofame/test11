using Avalonia.Controls;

namespace AvaCode.Views;

public partial class MainWindow : Window
{
    public MainWindow()
    {
        InitializeComponent();
    }
}