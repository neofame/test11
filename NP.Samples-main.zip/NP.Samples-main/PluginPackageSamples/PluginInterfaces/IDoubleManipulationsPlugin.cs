﻿namespace NP.PackagePluginsTest.PluginInterfaces
{
    public interface IDoubleManipulationsPlugin
    {
        double Plus(double number1, double number2);

        double Times(double number1, double number2);
    }
}