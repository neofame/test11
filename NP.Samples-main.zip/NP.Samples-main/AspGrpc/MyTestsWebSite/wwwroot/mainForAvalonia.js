﻿import { dotnet } from './_framework/dotnet.js'

const is_browser = typeof window != "undefined";
if (!is_browser) throw new Error(`Expected to be running in a browser`);

//const dotnetRuntime = await dotnet
//    .withDiagnosticTracing(false)
//    .withApplicationArgumentsFromQuery()
//    .create();

const { setModuleImports, getAssemblyExports, getConfig, runMain } = await dotnet
    .withDiagnosticTracing(false)
    .withApplicationArgumentsFromQuery()
    .create();

const config = getConfig();

await runMain(config.mainAssemblyName, [window.location.origin]);
