using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace MyTestsWebSite.Pages.AspGrpcTests
{
    public class AvaloniaGrpcTestPageModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
