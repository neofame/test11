using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace MyTestsWebSite.AspGrpcTests.Pages
{
    public class HtmlGrpcTestPageModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
