using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace MyTestsWebSite.Pages
{
    public class OnLineSamplesModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
