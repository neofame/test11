﻿namespace AvaGrpcClient
{
    public static class CommonData
    {
        public static string? Url { get; set; }
    }
}
