using Avalonia.Controls;

namespace AvaGrpcClient.Views;

public partial class MainWindow : Window
{
    public MainWindow()
    {
        InitializeComponent();
    }
}