Samples for [C# Linq Expressions in Easy Samples](https://www.codeproject.com/Articles/5345657/Csharp-Linq-Expressions-in-Easy-Samples) article.
